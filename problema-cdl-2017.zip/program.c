#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int months(char *s, char *create_string)
{
	if (s[3] == 'J' && s[4] == 'u' && s[5] == 'n')
	{
		create_string[5] = '0';
		create_string[6] = '1';
		return 0;
	}
	if (s[3] == 'F' && s[4] == 'e' && s[5] == 'b')
	{
		create_string[5] = '0';
		create_string[6] = '2';
		return 0;
	}
	if (s[3] == 'M' && s[4] == 'a' && s[5] == 'r')
	{
		create_string[5] = '0';
		create_string[6] = '3';
		return 0;
	}
	if (s[3] == 'A' && s[4] == 'p' && s[5] == 'r')
	{
		create_string[5] = '0';
		create_string[6] = '4';
		return 0;
	}
	if (s[3] == 'M' && s[4] == 'a' && s[5] == 'y')
	{
		create_string[5] = '0';
		create_string[6] = '5';
		return 0;
	}
	if (s[3] == 'J' && s[4] == 'u' && s[5] == 'n')
	{
		create_string[5] = '0';
		create_string[6] = '6';
		return 1;
	}
	if (s[3] == 'J' && s[4] == 'u' && s[5] == 'l')
	{
		create_string[5] = '0';
		create_string[6] = '7';
		return 1;
	}
	if (s[3] == 'A' && s[4] == 'u' && s[5] == 'g')
	{
		create_string[5] = '0';
		create_string[6] = '8';
		return 0;
	}
	if (s[3] == 'S' && s[4] == 'e' && s[5] == 'p')
	{
		create_string[5] = '0';
		create_string[6] = '9';
		return 1;
	}
	if (s[3] == 'O' && s[4] == 'c' && s[5] == 't')
	{
		create_string[5] = '1';
		create_string[6] = '0';
		return 0;
	}
	if (s[3] == 'N' && s[4] == 'o' && s[5] == 'v')
	{
		create_string[5] = '1';
		create_string[6] = '1';
		return 0;
	}
	if (s[3] == 'D' && s[4] == 'e' && s[5] == 'c')
	{
		create_string[5] = '1';
		create_string[6] = '2';
		return 0;
	}
}
typedef struct
{
	int an;
	int luna;
	int zi;
	int ora;
	int minut;
}data;

typedef struct
{
	data *frecventa;
	char **endpoint;
	int poz_start;
	int poz_stop;
	int *nr_total;
	int *nr_corect;
}list;

int check(data compare, data current_state)
{
	if(compare.an<current_state.an)
		return 1;
	if(compare.an>current_state.an)
		return 0;
	else
	{
		if(compare.luna<current_state.luna)
			return 1;
		if(compare.luna>current_state.luna)
			return 0;
		else
		{
			if(compare.zi<current_state.zi)
				return 1;
			if(compare.zi>current_state.zi)
				return 0;
			else
			{
				if(compare.ora<current_state.ora)
					return 1;
				if(compare.ora>current_state.ora)
					return 0;
				else
					if(compare.minut>=current_state.minut)
						return 0;
					else
						return 1;
			}
		}
	}
}

int second_check(data compare, data current_state)
{
	if(compare.an<current_state.an)
		return 1;
	if(compare.an>current_state.an)
		return 0;
	else
	{
		if(compare.luna<current_state.luna)
			return 1;
		if(compare.luna>current_state.luna)
			return 0;
		else
		{
			if(compare.zi<current_state.zi)
				return 1;
			if(compare.zi>current_state.zi)
				return 0;
			else
			{
				if(compare.ora<current_state.ora)
					return 1;
				if(compare.ora>current_state.ora)
					return 0;
				else
					if(compare.minut>current_state.minut)
						return 0;
					else
						return 1;
			}
		}
	}
}


int main(int argc, char const *argv[])
{
	int interval=1, i, contor, ok, j, num_lines=0, ok2, nr, count=0;
	int *frecv_cod, *poz;   // *frecv_an, *frecv_luna, *frecv_zi, *frecv_ora, *frecv_min;
	char *s, line[250], *create_string, **endpoint, an[5], luna[3], zi[3], ora[3], minut[3];
	data interval_split, current_state, *frecventa;
	list final_list;

	memset(line, 0, 250);
	memset(an, 0, 5);
	memset(luna, 0, 5);
	memset(zi, 0, 5);
	memset(ora, 0, 5);
	memset(minut, 0, 5);

	for(i=0; i<argc; i++)
		if ( strcmp(argv[i], "--interval")==0 )
		{
			interval = atoi(argv[i+1]);
		}


	FILE *fin = fopen(argv[1], "rt");
	FILE *interm = fopen("intermediar", "w+");
	FILE *fout = fopen("final", "w+");

	

	interval_split.minut = interval%60; // interval e dat ca argument sau e implicit 1 minut
	interval_split.ora = interval/60;
	interval_split.zi = interval_split.ora/24;
	interval_split.ora = interval_split.ora%24;
	interval_split.luna = interval_split.zi/30;
	interval_split.zi = interval_split.zi%30;
	interval_split.an = interval_split.luna/12;
	interval_split.luna = interval_split.luna%12;

	while ( fgets (line, 250, fin) ) // ia cate o linie din fisierul de test
	{
		num_lines++; 
		contor = 0;
		s = strtok(line, "[]\"");
		while ( s != NULL )
		{
			++contor;
			if (contor == 2) // partea cu data din fiecare linie
			{
				create_string = (char*)calloc(strlen(s), sizeof(s));
				ok = months(s, create_string); // verifica daca lunile sunt trecute cu 3 sau 4 litere
				create_string[0] = s[7 + ok];
				create_string[1] = s[8 + ok];
				create_string[2] = s[9 + ok];
				create_string[3] = s[10 + ok];
	//			printf("%d\n", ok);
				create_string[4] = '-';
				create_string[7] = '-';
				create_string[8] = s[0];
				create_string[9] = s[1];
				create_string[10] = 'T';
				for(i=12+ok; i<=16+ok; i++)
				{
					create_string[i-1-ok] = s[i];
				}
				fprintf(interm, "%s ", create_string); // pun in fisierul intermediar stringul extras
				free(create_string); // eliberez memoria
			}
			if (contor == 4) // extrag endpoint-ul
			{
				i = 4; j=0;
				create_string = (char*)calloc(strlen(s), sizeof(s));
				while( (s[i-4] != 'h') || (s[i-3] != 't') || (s[i-2] != 'm') || (s[i-1] != 'l') )
				{
					create_string[j++] = s[i++];
				}
				fprintf(interm, "%s ", create_string);
				free(create_string); // eliberez memoria
			}
			if (contor == 5) // extrag status code-ul
			{
				create_string = (char*)calloc(strlen(s), sizeof(s));
				create_string[0] = s[1];
				create_string[1] = s[2];
				create_string[2] = s[3];
				fprintf(interm, "%s\n", create_string);
				free(create_string); // eliberez memoria
			}
			
			s = strtok(NULL, "[]\"");
		}
	} // aici se termina crearea fisierului intermediar, urmeaza sa prelucrez datele din el ca sa obtin statistica

	endpoint = (char**)malloc( num_lines * sizeof(char*) ); // salvez endpointu-rile ca sa le compar
	for(i=0; i<num_lines; i++)
		endpoint[i] = (char*)calloc( 250, sizeof(char) );

	final_list.endpoint = (char**)malloc( num_lines * sizeof(char*) ); // lista finala a endpointu-rilor
	for(i=0; i<num_lines; i++)
		final_list.endpoint[i] = (char*)calloc( 250, sizeof(char) );
	final_list.nr_corect = (int*)calloc( num_lines, sizeof(int*));
	final_list.nr_total = (int*)calloc( num_lines, sizeof(int*));
	final_list.poz_stop = 0;
	final_list.poz_start = 0;

	frecv_cod = (int*)calloc( num_lines, sizeof(int) ); // salvez 1 daca statuscode = 2xx, 0 altfel
	frecventa = (data*)calloc( num_lines, sizeof(data) );
	final_list.frecventa = (data*)calloc( num_lines, sizeof(data) );

	i = 0;


	poz = (int*)calloc(num_lines, sizeof(int));
	fseek(interm, 0, SEEK_SET);
	nr=0;


	while ( fgets (line, 250, interm) )
	{
		s = strtok(line, " "); // prima bucata de string (data)
		// impart data pe componente ca sa o manipulez mai usor
		for(i=0; i<4; i++)
			an[i] = s[i];
		luna[0] = s[++i]; luna[1] = s[++i]; i++;
		zi[0] = s[++i]; zi[1] = s[++i]; i++;
		ora[0] = s[++i]; ora[1] = s[++i]; i++;
		minut[0] = s[++i]; minut[1] = s[++i];

		//puts(minut);

		frecventa[nr].minut = atoi(minut);
		frecventa[nr].ora = atoi(ora);
		frecventa[nr].zi = atoi(zi);
		frecventa[nr].luna = atoi(luna);
		frecventa[nr].an = atoi(an);

		if (nr>0 && frecventa[nr].minut!=frecventa[nr-1].minut) // poz[] retine pozitiile pe care se schimba minutul
		{
			poz[++count] = nr; // count reprezinta pozitiile respective
		}

		s = strtok(NULL, " "); // a doua bucata de string (endpoint-ul)
		strcpy(endpoint[nr], s);          // SETEZ ENDPOINTU-RILE
		s = strtok(NULL, " "); // ultima bucata de string (codul 2xx)

		frecv_cod[nr] = atoi(s)/100;
		if (frecv_cod[nr] != 2)
		{
			frecv_cod[nr] = 0;
		}
		else
		{
			frecv_cod[nr] = 1; // e 1 daca are prefixul 2, 0 altfel
		}
		nr++;
	} // frecventa[nr] tine evidenta datei entry-ului de pe pozitia nr

	
	current_state = frecventa[0];
	i=0;

	current_state.an += interval_split.an;
	current_state.luna += interval_split.luna;
	current_state.zi += interval_split.zi;
	current_state.ora += interval_split.ora;
	current_state.minut += interval_split.minut;

	count=0;


	do
	{
		ok=0; // verifica daca mai sunt entry-uri in intervalul curent

	//	i = poz[count];

		//ajustez current_state sa se potriveasca in "tiparele" fusului orar
		current_state.ora += current_state.minut/60;
		current_state.minut = current_state.minut%60;
		current_state.zi += current_state.ora/24;
		current_state.ora = current_state.ora%24;
		current_state.luna += current_state.zi/30;
		current_state.zi = current_state.zi%30;
		current_state.an += current_state.luna/13;
		current_state.luna = current_state.luna%13;

		ok = check(frecventa[i], current_state);


		while(ok == 1) // inca ma aflu in intervalul curent
		{
			ok2 = 0; // verifica daca mai apare endpointul curent in lista finala de endpointuri

			for(j=final_list.poz_start; j<final_list.poz_stop; j++) // caut in lista daca mai am endpointul
			{
				if ( strcmp(endpoint[i], final_list.endpoint[j]) == 0 ) // endpoint gasit in lista
				{
					final_list.nr_total[j]++; // marim numarul total de aparitii
					if(frecv_cod[i] == 1)
						final_list.nr_corect[j]++; // daca prefixul e 2, creste probabilitatea
					ok2 = 1; // endpoint gasit in lista
				}
			}


			if( ok2 == 0 ) // daca endpointul nu era in lista il punem
			{
				strcpy( final_list.endpoint[ final_list.poz_stop ], endpoint[i] );
				final_list.nr_total[ final_list.poz_stop ]++; // marim nr total de aparitii
				if(frecv_cod[i] == 1)
					final_list.nr_corect[ final_list.poz_stop ]++; // daca prefixul e 2, marim probabilitatea
				final_list.frecventa[ final_list.poz_stop ].an = frecventa[i].an; // salvez in lista finala data primului entry al endpointului
				final_list.frecventa[ final_list.poz_stop ].luna = frecventa[i].luna;
				final_list.frecventa[ final_list.poz_stop ].zi = frecventa[i].zi;
				final_list.frecventa[ final_list.poz_stop ].ora = frecventa[i].ora;
				final_list.frecventa[ final_list.poz_stop ].minut = frecventa[i].minut;
				final_list.poz_stop++;
			}

			i++; // trecem mai departe in lista endpointurilor (nu cea finala)
			if ( i>=num_lines )
			{
				break; // iesim daca contorul i depaseste numarul de linii(entry-uri) din fisier
			}
			ok = check(frecventa[i], current_state); // verificam daca inca ne aflam in intervalul curent
		}



		final_list.poz_start = final_list.poz_stop; // am iesit din intervalul curent, asa ca noua pozitie de start
													// va fi contorizata "de la 0" si repetam procesul cu urmatoarele
													// endpointuri din lista

		current_state.minut++;
		count++;
	}while( i< num_lines && poz[count]!=0 );

	


	
	float calculus=0.0;
	char string[250];
	memset(string, 0, 250);
	int aux;


	// sortare dupa endpoint
	j=0;
	for (i = 0; i < final_list.poz_stop-1; ++i)
	{
		j=i+1;
		while ( j<final_list.poz_stop && second_check(final_list.frecventa[j], final_list.frecventa[i])==1 )
		{

			if( strcmp(final_list.endpoint[i], final_list.endpoint[j]) > 0 )
			{
				strcpy(string, final_list.endpoint[i]); // interschimb endpointurile
				strcpy(final_list.endpoint[i], final_list.endpoint[j]);
				strcpy(final_list.endpoint[j], string);

				aux = final_list.nr_corect[i]; // interschimb procentele
				final_list.nr_corect[i] = final_list.nr_corect[j];
				final_list.nr_corect[j] = aux;

				aux = final_list.nr_total[i]; // interschimb counturile
				final_list.nr_total[i] = final_list.nr_total[j];
				final_list.nr_total[j] = aux;
			}
			j++;
		}


	}



	for(i=0; i<final_list.poz_stop; i++) // afisarea
	{
		printf("%02d-%02d-%02dT%02d:%02d %d %s ", final_list.frecventa[i].an, final_list.frecventa[i].luna,
		final_list.frecventa[i].zi, final_list.frecventa[i].ora, final_list.frecventa[i].minut, interval, final_list.endpoint[i]);
		calculus = (float)final_list.nr_corect[i]/final_list.nr_total[i];
		printf("%0.2f\n", 100*calculus);
	}


	// eiberez memoria
	for(i=0; i<num_lines; i++)
		free(endpoint[i]);
	free(endpoint);
	for(i=0; i<num_lines; i++)
		free(final_list.endpoint[i]);
	free(final_list.endpoint);
	free(frecv_cod);
	free(frecventa);
	free(final_list.frecventa);
	free(final_list.nr_corect);
	free(final_list.nr_total);
	free(poz);

	// inchid fisierele
	fclose (fin);
	fclose (interm);
	fclose (fout);

	return 0;
}